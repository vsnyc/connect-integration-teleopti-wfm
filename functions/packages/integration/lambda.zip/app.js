var AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
var handler = require('./main.js')

var testEvent = { version: '0',
    id: '1e304a25-cdd9-6431-19d2-93d20dbf04ed',
    'detail-type': 'Scheduled Event',
    source: 'aws.events',
    account: '910000848896',
    time: '2020-03-24T06:36:43Z',
    region: 'us-east-1',
    resources:
        [ 'arn:aws:events:us-east-1:910000848896:rule/test-teleopti' ],
    detail: {} };
var testContext = {
    functionVersion: '$LATEST',
    functionName: 'teleopti-integration-763b5d40-6d98-11ea-b2f6-0acaf3694d17',
    memoryLimitInMB: '256',
    logGroupName:
        '/aws/lambda/teleopti-integration-763b5d40-6d98-11ea-b2f6-0acaf3694d17',
    logStreamName: '2020/03/24/[$LATEST]9ff931d13d3240929484f77092dc80c0',
    clientContext: undefined,
    identity: undefined,
    invokedFunctionArn:
        'arn:aws:lambda:us-east-1:910000848896:function:teleopti-integration-763b5d40-6d98-11ea-b2f6-0acaf3694d17',
    awsRequestId: '4ee546c8-09d5-45cf-90e0-6dd0af0319f4'};
handler.handle(testEvent, testContext);